if (pass_it["x"]) {
    out["pass_it"] = pass_it;
} else {
    out["pass_it"] = {
        "x": '',
        "y": ''
    };
}