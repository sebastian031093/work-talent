var iframeDocument = document.querySelector('iframe[]').contentWindow.document;
var html_jobs = iframeDocument.querySelectorAll('JobsSelector');